/**
* Theme:  Velonic - Responsive Bootstrap 5 Admin & Dashboard
* Author: Techzaa
* File:   Responsive table
*/

import 'admin-resources/rwd-table/rwd-table.min.js'

!function(t){"use strict";function e(){}e.prototype.init=function(){document.addEventListener("DOMContentLoaded",function(){t(".table-rep-plugin").responsiveTable("update"),t(".btn-toolbar [data-toggle=dropdown]").attr("data-bs-toggle","dropdown")})},t.ResponsiveTable=new e,t.ResponsiveTable.Constructor=e}(window.jQuery),function(){"use strict";window.jQuery.ResponsiveTable.init()}();
