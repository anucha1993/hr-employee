import $ from 'jquery'
window.$ = $;
window.jQuery = $;
window.jquery = $;

import 'simplebar'
import moment from "moment";
window.moment = moment;


