<!-- bundle -->
@yield('script')
<!-- App js -->
@yield('script-bottom')

<!-- Stack scripts for individual pages -->
@stack('scripts')