<div>
    <br>
    <div class="container-fluid">


        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


        <div class="card">
            <div class="card-header">
                <h2 class="">รายชื่อลูกค้า</h2>
                <div class="d-flex justify-content-end gap-2">
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create customer')): ?>
                    <a href="<?php echo e(route('customer.create')); ?>" class="btn btn-success">
                        <i class="fa fa-plus"></i> เพิ่มลูกค้าใหม่
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">



                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>ชื่อบริษัท</th>
                                <th>เลขผู้เสียภาษี</th>
                                <th>สาขา</th>
                                <th>จังหวัด</th>
                                <th>วันที่เหลือ</th>
                                <th>สถานะ</th>
                                <th>ดำเนินการ</th>
                            </tr>
                        </thead>
                        <tbody>
                             <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $this->customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($customer->customer_name); ?></td>
                                    <td><?php echo e($customer->customer_taxid); ?></td>
                                    <td><?php echo e($customer->branch->value); ?></td>
                                    <td><?php echo e($customer->customer_address_province); ?></td>

                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if($customer->latestContract): ?>
                                            <?php
                                                $remaining = \Carbon\Carbon::parse(
                                                    $customer->latestContract->contract_end_date,
                                                )->diffInDays(now(), false);
                                            ?>
                                            <!--[if BLOCK]><![endif]--><?php if($remaining < 0): ?>
                                                เหลือ <?php echo e(abs($remaining)); ?> วัน
                                            <?php elseif($remaining === 0): ?>
                                                วันสุดท้าย
                                            <?php else: ?>
                                                หมดอายุแล้ว <?php echo e($remaining); ?> วัน
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php else: ?>
                                            -
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                    <td><?php echo getStatusCutomerBadge($customer->customer_status); ?></td>
                                    <td>
                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit customer')): ?>
                                             <a href="<?php echo e(route('customer.edit', $customer->id)); ?>"
                                            class="btn btn-sm btn-warning">แก้ไข</a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete customer')): ?>
                                        <button type="button"
                                            onclick="if (confirm('ยืนยันการลบ?')) { window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('delete', <?php echo e($customer->id); ?>) }"
                                            class="btn btn-sm btn-danger">
                                            ลบ
                                        </button>
                                         <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">ไม่พบข้อมูลลูกค้า</td>
                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tbody>
                    </table>
                  <div class="card-footer">
                        <div class="d-flex justify-content-between align-items-center">
                            <?php echo e($this->customers->links('pagination::bootstrap-5')); ?>

                            
                            <a href="<?php echo e(route('reports.customer-employee')); ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fa fa-file-excel"></i> ออกรายงานพนักงาน
                            </a>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\laragon\www\hr-employee\resources\views/livewire/customers/customer-index.blade.php ENDPATH**/ ?>