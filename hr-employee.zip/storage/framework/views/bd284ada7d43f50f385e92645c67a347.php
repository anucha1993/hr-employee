<div>
<div class="container-fluid px-0">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0 fw-bold text-primary">รายการโปรไฟล์</h4>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit profile')): ?>
    <button class="btn btn-primary shadow-sm px-4 py-2" data-bs-toggle="modal" data-bs-target="#modal-profile-form">
      <i class="bi bi-plus-circle me-1"></i> สร้างโปรไฟล์
    </button>
    <?php endif; ?>
  </div>

  <div class="table-responsive rounded shadow-sm">
    <table class="table table-hover align-middle mb-4 bg-white">
      
      <thead class="table-light">
        <tr>
          <th class="text-center" style="width:40%">ชื่อโปรไฟล์</th>
          <th class="text-center" style="width:60%">จัดการ</th>
        </tr>
      </thead>

      <tbody>
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="text-center fw-semibold"><?php echo e($role->name); ?></td>
            <td class="text-center">
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit profile')): ?>
              <button class="btn btn-outline-info btn-sm me-2" wire:click="editProfile(<?php echo e($role->id); ?>)" data-bs-toggle="modal" data-bs-target="#modal-profile-form">
                <i class="bi bi-pencil-square"></i> แก้ไข
              </button>
              <?php endif; ?>

               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit profile')): ?>
              <button class="btn btn-outline-warning btn-sm" wire:click="openPermissionModal(<?php echo e($role->id); ?>)" data-bs-toggle="modal" data-bs-target="#modal-permission-assignment">
                <i class="bi bi-shield-lock"></i> กำหนดสิทธิ์
              </button>
                 <?php endif; ?>
                 
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="2" class="text-center text-muted">ไม่มีโปรไฟล์</td>
          </tr>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
      </tbody>
    </table>
  </div>
</div>

<!-- Modal สร้าง/แก้ไขโปรไฟล์ -->
<div wire:ignore.self class="modal fade" id="modal-profile-form" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form wire:submit.prevent="saveProfile">
        <div class="modal-header">
          <h5 class="modal-title">จัดการโปรไฟล์</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="text" wire:model.defer="name" class="form-control" placeholder="ชื่อโปรไฟล์">
          <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
          <button class="btn btn-primary" type="submit">บันทึก</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal กำหนดสิทธิ์ -->
<div wire:ignore.self class="modal fade" id="modal-permission-assignment" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form wire:submit.prevent="savePermissions">
        <div class="modal-header">
          <h5 class="modal-title">กำหนดสิทธิ์</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $groupedPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-3">
              <strong><?php echo e(ucfirst($group)); ?></strong>
              <div class="row">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-md-4">
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" wire:model.defer="selectedPermissions" value="<?php echo e($permission['name']); ?>" id="perm_<?php echo e($permission['id']); ?>">
                      <label class="form-check-label" for="perm_<?php echo e($permission['id']); ?>">
                        <?php echo e($permission['name']); ?>

                      </label>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
          <button class="btn btn-primary" type="submit">บันทึกสิทธิ์</button>
        </div>
      </form>
    </div>
  </div>
</div>
</div>
</div>
<?php /**PATH C:\laragon\www\hr-employee\resources\views/livewire/roles/profile-index.blade.php ENDPATH**/ ?>