<div wire:ignore.self class="modal fade" id="modal-profile-form" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form wire:submit.prevent="save">
        <div class="modal-header">
          <h5 class="modal-title"><?php echo e($role_id ? 'แก้ไขโปรไฟล์' : 'สร้างโปรไฟล์'); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">
          <div class="mb-3">
            <label for="profile-name" class="form-label">ชื่อโปรไฟล์</label>
            <input wire:model.defer="name" type="text" class="form-control">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>
        </div>

        <div class="modal-footer">
          <button class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
          <button class="btn btn-primary" type="submit">บันทึก</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php /**PATH C:\laragon\www\hr-employee\resources\views/livewire/roles/profile-form.blade.php ENDPATH**/ ?>