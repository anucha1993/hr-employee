<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 text-center">
                <script>document.write(new Date().getFullYear())</script> © Velonic - Theme by <b>Techzaa</b>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer --><?php /**PATH C:\laragon\www\hr-employee\resources\views/layouts/shared/footer.blade.php ENDPATH**/ ?>