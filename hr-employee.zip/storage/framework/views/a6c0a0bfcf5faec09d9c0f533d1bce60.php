<div>
    <div class="container-fluid">
        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="alert alert-success mt-2"><?php echo e(session('message')); ?></div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <div class="card card-primary card-outline mt-3">
            <div class="card-header d-flex justify-content-between ">
                <h3 class="card-title">Global Sets</h3>
                <!-- ปุ่มเปิด Modal -->
                  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit global')): ?>
              <button type="button" class="btn btn-primary" wire:click="create" data-bs-toggle="modal" data-bs-target="#globalSetModal">
    <i class="fa fa-add"></i> เพิ่ม
</button>
<?php endif; ?>
            </div>
            <div class="card-body">
                <table class="table table">
                    <thead class="bg-light">
                        <tr>
                            <th>ID</th>
                            <th>ชื่อ</th>
                            <th>คำอธิบาย</th>
                            <th class="text-center">จำนวนค่า</th>
                            <th class="text-right">จัดการ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $globalSets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $set): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($set->id); ?></td>
                                <td><?php echo e($set->name); ?></td>
                                <td><?php echo e($set->description); ?></td>
                                <td class="text-center"><?php echo e($set->values_count); ?></td>
                                <td class="text-right">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit global')): ?>
                                        <button wire:click="edit(<?php echo e($set->id); ?>)" data-bs-toggle="modal" data-bs-target="#globalSetModal" class="btn btn-sm btn-warning">แก้ไข</button>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete global')): ?>
                                        <button wire:click="delete(<?php echo e($set->id); ?>)" class="btn btn-sm btn-danger">ลบ</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted">ไม่มีข้อมูล</td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Bootstrap Modal แบบ standard -->
        <div wire:ignore.self class="modal fade" id="globalSetModal" tabindex="-1" role="dialog" aria-labelledby="globalSetModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <form wire:submit.prevent="save">
                        <div class="modal-header">
                            <h5 class="modal-title" id="globalSetModalLabel"><?php echo e($editingId ? 'แก้ไข' : 'เพิ่ม'); ?> Global Set</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label>ชื่อ</label>
                                <input type="text" wire:model.defer="name" class="form-control">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <div class="form-group">
                                <label>คำอธิบาย</label>
                                <textarea wire:model.defer="description" class="form-control"></textarea>
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                            <label class="font-weight-bold mt-2">Global Set Values</label>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row mb-2">
                                    <div class="col">
                                        <input type="text" wire:model="values.<?php echo e($index); ?>.value" class="form-control" placeholder="ค่า">
                                    </div>
                                    <div class="col">
                                        <select wire:model="values.<?php echo e($index); ?>.status" class="form-select">
                                            <option value="Enable">Enable</option>
                                            <option value="Disable">Disable</option>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <button type="button" wire:click="removeValue(<?php echo e($index); ?>)" class="btn btn-sm btn-danger">ลบ</button>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            <button type="button" wire:click="addValue" class="btn btn-sm btn-secondary">+ เพิ่มค่า</button>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
                            <button type="submit" class="btn btn-primary">บันทึก</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('livewire:initialized', function () {
        // เมื่อบันทึกสำเร็จ ให้ปิด modal
        window.Livewire.find('<?php echo e($_instance->getId()); ?>').on('closeModal', () => {
            const modal = bootstrap.Modal.getInstance(document.getElementById('globalSetModal'));
            if (modal) {
                modal.hide();
            }
        });
    });
</script>
<?php /**PATH C:\laragon\www\hr-employee\resources\views/livewire/globalsets/global-set-manager.blade.php ENDPATH**/ ?>