<!-- bundle -->
<?php echo $__env->yieldContent('script'); ?>
<!-- App js -->
<?php echo $__env->yieldContent('script-bottom'); ?>

<!-- Stack scripts for individual pages -->
<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH C:\laragon\www\hr-employee\resources\views/layouts/shared/footer-scripts.blade.php ENDPATH**/ ?>