<div>
    <h3>โปรไฟล์</h3>
    <input type="text" wire:model="search" class="form-control mb-2" placeholder="ค้นหาโปรไฟล์...">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ชื่อโปรไฟล์</th>
                <th>การจัดการ</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($role->name); ?></td>
                <td>
                    <a class="btn btn-sm btn-warning" href="<?php echo e(route('profiles.edit', $role->id)); ?>">แก้ไข</a>
                    <button class="btn btn-sm btn-danger" wire:click="delete(<?php echo e($role->id); ?>)">ลบ</button>
                    <a class="btn btn-sm btn-info" href="<?php echo e(route('profiles.permission', $role->id)); ?>">กำหนดสิทธิ์</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>
    <?php echo e($roles->links()); ?>

    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
        <div class="alert alert-success mt-2"><?php echo e(session('success')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\hr-employee\resources\views/livewire/profiles/profile-index.blade.php ENDPATH**/ ?>